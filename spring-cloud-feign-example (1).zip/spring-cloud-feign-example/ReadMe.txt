Use below URL(GET Request):
http://localhost:8090/customers/CUST1

Above will hit customer-service, which will further hit product-service

Even post call is made from customer-service to product-service, when above ulr is used, observe it in source code