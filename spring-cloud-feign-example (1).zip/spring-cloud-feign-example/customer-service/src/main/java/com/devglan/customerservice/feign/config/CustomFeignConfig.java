package com.devglan.customerservice.feign.config;
/*
import feign.Contract;
import feign.auth.BasicAuthRequestInterceptor;
import feign.codec.Encoder;
import feign.okhttp.OkHttpClient;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

public class CustomFeignConfig {

    @Bean
    public Contract feignContract() {
        return new feign.Contract.Default();
    }
    
    @Bean
    public Encoder feignEncoder() {

        HttpMessageConverter jacksonConverter = new MappingJackson2HttpMessageConverter();

        ObjectFactory<HttpMessageConverters> objectFactory = () -> new HttpMessageConverters(jacksonConverter);

        return new SpringEncoder(objectFactory);

    }

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor("user", "password");
    }

    @Bean
    public OkHttpClient client() {
        return new OkHttpClient();
    }

}
*/