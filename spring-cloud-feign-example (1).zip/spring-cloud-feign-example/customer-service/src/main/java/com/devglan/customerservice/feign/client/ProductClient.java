package com.devglan.customerservice.feign.client;

//import com.devglan.customerservice.feign.config.CustomFeignConfig;
import com.devglan.commons.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

//@FeignClient(name="product-service", configuration = CustomFeignConfig.class)
@FeignClient(name="product-service")
public interface ProductClient {

    @GetMapping("/products")
    List<Product> listProducts();

    @GetMapping("/products")
    Product getProductById(@RequestParam("id") String id);

    @PostMapping("/products")
    //@RequestMapping(consumes = "application/json", produces = "application/json", method = RequestMethod.POST)
    Product create(@RequestBody Product product);

    @GetMapping("/products/customer")
    List<Product> listProductsByCustomerId(@RequestParam("custId") String custId);
}
